import jwt from "jsonwebtoken";
import { getAuthClaims } from "../../utils/authClaims.js";
import { sendOk } from "../../utils/response.js";
import { sendError } from "../../utils/errors.js";
import { generateRecoveryActionLink } from "../../services/authRecovery.js";

const loginBodySchema = {
  type: "object",
  properties: {
    identifier: { type: "string", minLength: 1 },
    nombre_usuario: { type: "string", minLength: 1 },
    username: { type: "string", minLength: 1 },
    email: { type: "string", minLength: 1 },
    contrasena: { type: "string", minLength: 1 },
    password: { type: "string", minLength: 1 },
  },
  anyOf: [
    { required: ["identifier"] },
    { required: ["email"] },
    { required: ["nombre_usuario"] },
    { required: ["username"] },
  ],
};

const exchangeBodySchema = {
  type: ["object", "null"],
  properties: {
    supabase_token: { type: "string", minLength: 1 },
    access_token: { type: "string", minLength: 1 },
    token: { type: "string", minLength: 1 },
  },
  additionalProperties: true,
};

const registerBodySchema = {
  type: "object",
  properties: {
    nombres: { type: "string", minLength: 1, maxLength: 120 },
    apellidos: { type: "string", minLength: 1, maxLength: 120 },
    email: { type: "string", minLength: 5, maxLength: 160 },
    contrasena: { type: "string", minLength: 8, maxLength: 120 },
    confirmar_contrasena: { type: "string", minLength: 8, maxLength: 120 },
    acepta_terminos: { type: "boolean" },
    consentimiento_marketing: { type: "boolean" },
    id_sucursal_origen: { type: ["string", "null"], format: "uuid" },
  },
  required: [
    "nombres",
    "apellidos",
    "email",
    "contrasena",
    "confirmar_contrasena",
    "acepta_terminos",
  ],
  additionalProperties: false,
};

const requestIdSchema = { type: "string" };

const errorResponseSchema = {
  type: "object",
  properties: {
    ok: { type: "boolean" },
    error: {
      type: "object",
      properties: {
        code: { type: "string" },
        message: { type: "string" },
        details: {},
      },
      required: ["code", "message"],
      additionalProperties: true,
    },
    requestId: requestIdSchema,
  },
  required: ["ok", "error"],
  additionalProperties: true,
};

const loginResponseSchema = {
  200: {
    type: "object",
    properties: {
      ok: { type: "boolean" },
      data: {
        type: "object",
        properties: {
          token: { type: "string" },
          user: { type: "object", additionalProperties: true },
        },
        required: ["token", "user"],
        additionalProperties: true,
      },
      requestId: requestIdSchema,
    },
    required: ["ok", "data"],
    additionalProperties: true,
  },
};

const exchangeResponseSchema = {
  ...loginResponseSchema,
  400: errorResponseSchema,
  401: errorResponseSchema,
  403: errorResponseSchema,
  409: errorResponseSchema,
  500: errorResponseSchema,
};

const registerResponseSchema = {
  201: {
    type: "object",
    properties: {
      ok: { type: "boolean" },
      data: {
        type: "object",
        properties: {
          user: {
            type: "object",
            properties: {
              id_usuario: { type: "string", format: "uuid" },
              id_persona: { type: "string", format: "uuid" },
              id_cliente: { type: "string", format: "uuid" },
              email: { type: "string" },
              nombres: { type: "string" },
              apellidos: { type: "string" },
              estado_acceso: { type: "string" },
            },
            required: [
              "id_usuario",
              "id_persona",
              "id_cliente",
              "email",
              "nombres",
              "apellidos",
              "estado_acceso",
            ],
            additionalProperties: false,
          },
          cliente: {
            type: "object",
            properties: {
              id_cliente: { type: "string", format: "uuid" },
              id_sucursal_origen: { type: "string", format: "uuid" },
              estado: { type: "boolean" },
            },
            required: ["id_cliente", "id_sucursal_origen", "estado"],
            additionalProperties: false,
          },
          consentimientos: {
            type: "object",
            properties: {
              acepta_terminos: { type: "boolean" },
              acepta_terminos_at: { type: ["string", "null"] },
              consentimiento_marketing: { type: "boolean" },
              consentimiento_marketing_at: { type: ["string", "null"] },
            },
            required: [
              "acepta_terminos",
              "acepta_terminos_at",
              "consentimiento_marketing",
              "consentimiento_marketing_at",
            ],
            additionalProperties: false,
          },
        },
        required: ["user", "cliente", "consentimientos"],
        additionalProperties: false,
      },
      requestId: requestIdSchema,
    },
    required: ["ok", "data"],
    additionalProperties: true,
  },
  400: errorResponseSchema,
  409: errorResponseSchema,
  500: errorResponseSchema,
};

const meResponseSchema = {
  200: {
    type: "object",
    properties: {
      ok: { type: "boolean" },
      data: {
        type: "object",
        properties: {
          user: {
            type: "object",
            properties: {
              id_usuario: { type: "string", format: "uuid" },
              id_persona: { type: ["string", "null"], format: "uuid" },
              email: { type: ["string", "null"] },
              nombres: { type: ["string", "null"] },
              apellidos: { type: ["string", "null"] },
            },
            required: ["id_usuario", "id_persona", "email", "nombres", "apellidos"],
            additionalProperties: false,
          },
          roles: { type: "array", items: { type: "string" } },
          branch_ids: { type: "array", items: { type: "string", format: "uuid" } },
          empresa_id: { type: ["string", "null"], format: "uuid" },
          empleado_id: { type: ["string", "null"], format: "uuid" },
          cliente_id: { type: ["string", "null"], format: "uuid" },
        },
        required: ["user", "roles", "branch_ids", "empresa_id", "empleado_id", "cliente_id"],
        additionalProperties: false,
      },
      requestId: requestIdSchema,
    },
    required: ["ok", "data"],
    additionalProperties: true,
  },
  401: errorResponseSchema,
  500: errorResponseSchema,
};

const RESET_MAX_ATTEMPTS = Number(process.env.RESET_MAX_ATTEMPTS || 3);
const RESET_WINDOW_MS = Number(process.env.RESET_WINDOW_MS || 15 * 60_000);
const RESET_BLOCK_MS = Number(process.env.RESET_BLOCK_MS || 30 * 60_000);
const resetAttemptsByEmail = new Map();
const ACCESS_STATUS = {
  PENDING_PASSWORD: "pendiente_password",
  ACTIVE: "activo",
  BLOCKED: "bloqueado",
  INACTIVE: "inactivo",
};
const PASSWORD_COMPLEXITY_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
let clientsConsentColumnsCache = null;

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function normalizeRequiredText(value) {
  return String(value || "").normalize("NFC").trim();
}

function normalizeOptionalUuid(value) {
  const raw = String(value || "").trim();
  return raw || null;
}

function isSupabaseDuplicateError(error) {
  const code = String(error?.code || "").toLowerCase();
  const message = String(error?.message || "").toLowerCase();
  return code === "email_exists" || code === "user_already_exists" || message.includes("already registered");
}

function validatePublicPassword(password) {
  if (password.length < 8) return "La contrasena debe tener al menos 8 caracteres.";
  if (!PASSWORD_COMPLEXITY_REGEX.test(password)) {
    return "La contrasena debe incluir mayuscula, minuscula y numero.";
  }
  return null;
}

async function resolveRegisterBranchId(client, requestedBranchId) {
  const normalizedBranchId = normalizeOptionalUuid(requestedBranchId);

  if (normalizedBranchId) {
    const scoped = await client.query(
      `
        SELECT id_sucursal
        FROM public.sucursales
        WHERE id_sucursal = $1::uuid
          AND deleted_at IS NULL
          AND estado IS TRUE
        LIMIT 1
      `,
      [normalizedBranchId]
    );
    if (!scoped.rowCount) {
      throw {
        statusCode: 400,
        message: "La sucursal seleccionada no existe o no esta activa.",
        code: "AUTH_REGISTER_BRANCH_INVALID",
      };
    }
    return normalizedBranchId;
  }

  const fallback = await client.query(
    `
      SELECT id_sucursal
      FROM public.sucursales
      WHERE deleted_at IS NULL
        AND estado IS TRUE
      ORDER BY nombre_sucursal ASC, id_sucursal ASC
      LIMIT 1
    `
  );
  if (!fallback.rowCount) {
    throw {
      statusCode: 409,
      message: "No hay sucursales activas para registrar clientes en este momento.",
      code: "AUTH_REGISTER_BRANCH_REQUIRED",
    };
  }
  return fallback.rows[0].id_sucursal;
}

async function ensureRegisterEmailAvailability(client, email) {
  const correoResult = await client.query(
    `
      SELECT 1
      FROM public.correos
      WHERE LOWER(direccion_correo::text) = LOWER($1)
      LIMIT 1
    `,
    [email]
  );
  if (correoResult.rowCount) {
    throw {
      statusCode: 409,
      message: "El correo ya esta registrado.",
      code: "AUTH_REGISTER_EMAIL_EXISTS",
    };
  }

  const authResult = await client.query(
    `
      SELECT 1
      FROM auth.users
      WHERE LOWER(email::text) = LOWER($1)
      LIMIT 1
    `,
    [email]
  );
  if (authResult.rowCount) {
    throw {
      statusCode: 409,
      message: "El correo ya esta registrado.",
      code: "AUTH_REGISTER_EMAIL_EXISTS",
    };
  }
}

async function getClienteRoleId(client) {
  const roleResult = await client.query(
    `
      SELECT id_rol
      FROM public.roles
      WHERE nombre = 'cliente'
      LIMIT 1
    `
  );
  if (!roleResult.rowCount) {
    throw {
      statusCode: 500,
      message: "No existe el rol cliente en la configuracion interna.",
      code: "AUTH_REGISTER_CLIENT_ROLE_MISSING",
    };
  }
  return roleResult.rows[0].id_rol;
}

async function hasClientsConsentTimestampColumns(client) {
  if (clientsConsentColumnsCache !== null) {
    return clientsConsentColumnsCache;
  }

  const { rows } = await client.query(
    `
      SELECT column_name
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'clientes'
        AND column_name IN ('acepta_terminos_at', 'consentimiento_marketing_at')
    `
  );

  const columns = new Set(rows.map((row) => String(row.column_name)));
  clientsConsentColumnsCache =
    columns.has("acepta_terminos_at") && columns.has("consentimiento_marketing_at");
  return clientsConsentColumnsCache;
}

async function insertClientWithConsents(client, params) {
  const {
    idPersona,
    authUserId,
    branchId,
    consentimientoMarketing,
    aceptaTerminos,
    aceptaTerminosAt,
    consentimientoMarketingAt,
  } = params;

  const hasConsentTimestampColumns = await hasClientsConsentTimestampColumns(client);
  if (hasConsentTimestampColumns) {
    const insertWithTimestamps = await client.query(
      `
        INSERT INTO public.clientes (
          id_persona,
          id_usuario,
          fecha_ingreso,
          id_sucursal_origen,
          estado,
          consentimiento_marketing,
          acepta_terminos,
          consentimiento_marketing_at,
          acepta_terminos_at
        )
        VALUES (
          $1::uuid,
          $2::uuid,
          CURRENT_DATE,
          $3::uuid,
          TRUE,
          $4::boolean,
          $5::boolean,
          $6::timestamptz,
          $7::timestamptz
        )
        RETURNING id_cliente
      `,
      [
        idPersona,
        authUserId,
        branchId,
        consentimientoMarketing,
        aceptaTerminos,
        consentimientoMarketingAt,
        aceptaTerminosAt,
      ]
    );
    return insertWithTimestamps.rows[0].id_cliente;
  }

  // AM: Compatibilidad temporal por si aun no aplican la migracion de trazabilidad de consentimientos.
  const insertLegacy = await client.query(
    `
      INSERT INTO public.clientes (
        id_persona,
        id_usuario,
        fecha_ingreso,
        id_sucursal_origen,
        estado,
        consentimiento_marketing,
        acepta_terminos
      )
      VALUES (
        $1::uuid,
        $2::uuid,
        CURRENT_DATE,
        $3::uuid,
        TRUE,
        $4::boolean,
        $5::boolean
      )
      RETURNING id_cliente
    `,
    [idPersona, authUserId, branchId, consentimientoMarketing, aceptaTerminos]
  );
  return insertLegacy.rows[0].id_cliente;
}

function registerResetAttempt(emailKey) {
  const now = Date.now();
  let record = resetAttemptsByEmail.get(emailKey);

  if (!record) {
    record = { count: 0, windowStart: now, blockedUntil: 0 };
  }

  const windowSeconds = Math.ceil(RESET_WINDOW_MS / 1000);
  const blockSeconds = Math.ceil(RESET_BLOCK_MS / 1000);

  if (record.blockedUntil && now < record.blockedUntil) {
    return {
      blocked: true,
      retryAfterSeconds: Math.ceil((record.blockedUntil - now) / 1000),
      rateLimit: {
        max: RESET_MAX_ATTEMPTS,
        remaining: 0,
        windowSeconds,
        resetInSeconds: Math.ceil((record.windowStart + RESET_WINDOW_MS - now) / 1000),
        blockSeconds,
      },
    };
  }

  if (now - record.windowStart > RESET_WINDOW_MS) {
    record.count = 0;
    record.windowStart = now;
  }

  record.count += 1;

  if (record.count > RESET_MAX_ATTEMPTS) {
    record.blockedUntil = now + RESET_BLOCK_MS;
    resetAttemptsByEmail.set(emailKey, record);

    return {
      blocked: true,
      retryAfterSeconds: blockSeconds,
      rateLimit: {
        max: RESET_MAX_ATTEMPTS,
        remaining: 0,
        windowSeconds,
        resetInSeconds: windowSeconds,
        blockSeconds,
      },
    };
  }

  resetAttemptsByEmail.set(emailKey, record);

  return {
    blocked: false,
    rateLimit: {
      max: RESET_MAX_ATTEMPTS,
      remaining: Math.max(0, RESET_MAX_ATTEMPTS - record.count),
      windowSeconds,
      resetInSeconds: Math.max(0, Math.ceil((record.windowStart + RESET_WINDOW_MS - now) / 1000)),
      blockSeconds,
    },
  };
}

function signAppToken(payload, jwtSecret) {
  return jwt.sign(payload, jwtSecret, {
    expiresIn: process.env.JWT_EXPIRES_IN?.trim() || "12h",
    issuer: process.env.APP_JWT_ISSUER || "masterfade-api",
    audience: process.env.APP_JWT_AUDIENCE || "masterfade-app",
  });
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "").trim());
}

function getBearerToken(headerValue) {
  const raw = String(headerValue || "").trim();
  if (!raw) return null;
  const match = raw.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() || null;
}

function extractSupabaseToken(request) {
  const body = request.body || {};
  const bodyToken = String(
    body.supabase_token ?? body.access_token ?? body.token ?? ""
  ).trim();
  if (bodyToken) return bodyToken;
  return getBearerToken(request.headers.authorization);
}

function extractEmailFromSupabaseUser(user) {
  const directEmail = normalizeEmail(user?.email);
  if (directEmail) return directEmail;

  const metadataEmail = normalizeEmail(user?.user_metadata?.email);
  if (metadataEmail) return metadataEmail;

  const identities = Array.isArray(user?.identities) ? user.identities : [];
  for (const identity of identities) {
    const identityEmail = normalizeEmail(identity?.identity_data?.email);
    if (identityEmail) return identityEmail;
  }

  return "";
}

function normalizePgErrorText(value) {
  return String(value || "").trim().toLowerCase();
}

function isEmailConflictError(error) {
  const detail = normalizePgErrorText(error?.detail);
  const constraint = normalizePgErrorText(error?.constraint);
  return (
    detail.includes("direccion_correo") ||
    detail.includes("(email)") ||
    constraint.includes("correo")
  );
}

function isUserIdConflictError(error) {
  const detail = normalizePgErrorText(error?.detail);
  const constraint = normalizePgErrorText(error?.constraint);
  return detail.includes("(id_usuario)") || constraint.includes("usuarios_pkey");
}

async function resolveExchangeBranchId(client) {
  const preferredBranchId = normalizeOptionalUuid(process.env.AUTH_EXCHANGE_DEFAULT_BRANCH_ID);

  if (preferredBranchId) {
    if (!UUID_REGEX.test(preferredBranchId)) {
      throw {
        statusCode: 500,
        message: "AUTH_EXCHANGE_DEFAULT_BRANCH_ID no tiene formato UUID valido.",
        code: "AUTH_EXCHANGE_BRANCH_CONFIG_INVALID",
      };
    }
    return resolveRegisterBranchId(client, preferredBranchId);
  }

  return resolveRegisterBranchId(client, null);
}

function buildSocialPersonaNames(supabaseUser) {
  const metadata = supabaseUser?.user_metadata || {};
  const givenName = normalizeRequiredText(metadata.given_name);
  const familyName = normalizeRequiredText(metadata.family_name);
  const fullName = normalizeRequiredText(
    metadata.full_name || metadata.name || `${givenName} ${familyName}`.trim()
  );

  let nombres = givenName;
  let apellidos = familyName;

  if (!nombres && fullName) {
    const parts = fullName.split(/\s+/).filter(Boolean);
    if (parts.length === 1) {
      nombres = parts[0];
      apellidos = "Cliente";
    } else {
      nombres = parts.shift() || "Cliente";
      apellidos = parts.join(" ") || "Cliente";
    }
  }

  if (!nombres) nombres = "Cliente";
  if (!apellidos) apellidos = "Google";

  return { nombres, apellidos };
}

async function ensureExchangeEmailAvailability(client, email, authUserId) {
  const conflict = await client.query(
    `
      SELECT 1
      FROM public.correos c
      JOIN public.usuarios u
        ON u.id_persona = c.id_persona
      WHERE LOWER(c.direccion_correo::text) = LOWER($1)
        AND u.deleted_at IS NULL
        AND u.id_usuario <> $2::uuid
      LIMIT 1
    `,
    [email, authUserId]
  );

  if (conflict.rowCount) {
    throw {
      statusCode: 409,
      message: "El correo ya esta vinculado a otra cuenta interna.",
      code: "AUTH_EXCHANGE_EMAIL_EXISTS",
    };
  }
}

async function ensureExchangeInternalUser(app, supabaseUser) {
  const authUserId = String(supabaseUser?.id || "").trim();
  if (!authUserId) {
    throw {
      statusCode: 401,
      message: "Token de Supabase invalido",
      code: "AUTH_SUPABASE_INVALID",
    };
  }

  const existing = await app.db.query(
    `
      SELECT id_usuario
      FROM public.usuarios
      WHERE id_usuario = $1::uuid
        AND deleted_at IS NULL
      LIMIT 1
    `,
    [authUserId]
  );
  if (existing.rowCount) {
    return { created: false, authUserId };
  }

  const email = extractEmailFromSupabaseUser(supabaseUser);
  if (!email || !isValidEmail(email)) {
    throw {
      statusCode: 400,
      message: "No se pudo resolver un correo valido desde la identidad social.",
      code: "AUTH_EXCHANGE_EMAIL_REQUIRED",
    };
  }

  const { nombres, apellidos } = buildSocialPersonaNames(supabaseUser);
  const client = await app.db.connect();
  let transactionStarted = false;

  try {
    const branchId = await resolveExchangeBranchId(client);
    const clienteRoleId = await getClienteRoleId(client);
    await ensureExchangeEmailAvailability(client, email, authUserId);

    await client.query("BEGIN");
    transactionStarted = true;

    const personaInsert = await client.query(
      `
        INSERT INTO public.personas (nombres, apellidos)
        VALUES ($1, $2)
        RETURNING id_persona
      `,
      [nombres, apellidos]
    );
    const idPersona = personaInsert.rows[0].id_persona;

    await client.query(
      `
        INSERT INTO public.correos (id_persona, direccion_correo, es_principal, verificado)
        VALUES ($1::uuid, $2, TRUE, TRUE)
      `,
      [idPersona, email]
    );

    await client.query(
      `
        INSERT INTO public.usuarios (
          id_usuario,
          id_persona,
          estado,
          estado_acceso,
          credenciales_completadas_at,
          ultimo_login_at
        )
        VALUES ($1::uuid, $2::uuid, TRUE, $3, NOW(), NULL)
      `,
      [authUserId, idPersona, ACCESS_STATUS.ACTIVE]
    );

    await client.query(
      `
        INSERT INTO public.roles_usuarios (
          id_rol,
          id_usuario,
          id_sucursal,
          activo
        )
        VALUES ($1::uuid, $2::uuid, $3::uuid, TRUE)
      `,
      [clienteRoleId, authUserId, branchId]
    );

    await insertClientWithConsents(client, {
      idPersona,
      authUserId,
      branchId,
      consentimientoMarketing: false,
      aceptaTerminos: true,
      aceptaTerminosAt: new Date().toISOString(),
      consentimientoMarketingAt: null,
    });

    await client.query("COMMIT");
    transactionStarted = false;

    return { created: true, authUserId };
  } catch (error) {
    if (transactionStarted) {
      await client.query("ROLLBACK").catch(() => {});
    }

    if (error?.code === "23505") {
      if (isEmailConflictError(error)) {
        throw {
          statusCode: 409,
          message: "El correo de Google ya esta vinculado a otra cuenta de MasterFade. Usa tu login actual o contacta soporte.",
          code: "AUTH_EXCHANGE_EMAIL_EXISTS",
        };
      }

      if (isUserIdConflictError(error)) {
        const userNowExists = await app.db.query(
          `
            SELECT 1
            FROM public.usuarios
            WHERE id_usuario = $1::uuid
              AND deleted_at IS NULL
            LIMIT 1
          `,
          [authUserId]
        );

        if (userNowExists.rowCount) {
          return { created: false, authUserId };
        }
      }
    }

    throw error;
  } finally {
    client.release();
  }
}

async function syncAccessStateAfterLogin(app, userId) {
  const stateResult = await app.db.query(
    `
      SELECT estado_acceso, credenciales_completadas_at
      FROM public.usuarios
      WHERE id_usuario = $1::uuid
        AND deleted_at IS NULL
      LIMIT 1
    `,
    [userId]
  );

  if (!stateResult.rowCount) {
    return { ok: false, code: "AUTH_USER_NOT_ONBOARDED" };
  }

  const currentState = stateResult.rows[0].estado_acceso;
  if (currentState === ACCESS_STATUS.BLOCKED || currentState === ACCESS_STATUS.INACTIVE) {
    return { ok: false, code: "AUTH_ACCESS_BLOCKED", estado_acceso: currentState };
  }

  // AM: Login exitoso actualiza trazabilidad y promueve pendiente_password -> activo.
  const updateResult = await app.db.query(
    `
      UPDATE public.usuarios
      SET estado_acceso = CASE WHEN estado_acceso = $2 THEN $3 ELSE estado_acceso END,
          credenciales_completadas_at = COALESCE(credenciales_completadas_at, NOW()),
          ultimo_login_at = NOW(),
          updated_at = NOW()
      WHERE id_usuario = $1::uuid
      RETURNING estado_acceso, credenciales_completadas_at, ultimo_login_at
    `,
    [userId, ACCESS_STATUS.PENDING_PASSWORD, ACCESS_STATUS.ACTIVE]
  );

  return { ok: true, state: updateResult.rows[0] };
}

export default async function authRoutes(app) {
  app.get("/login", async (request, reply) => {
    return sendOk(
      reply,
      {
        message: "Login endpoint. Usa POST para autenticarte.",
        method: "GET",
      },
      { requestId: request.id }
    );
  });

  app.get(
    "/me",
    {
      preHandler: app.authenticate,
      schema: {
        headers: {
          type: "object",
          properties: {
            authorization: { type: "string" },
          },
        },
        response: meResponseSchema,
      },
    },
    async (request, reply) => {
      if (!app.db) {
        return sendError(reply, 500, "Base de datos no configurada", {
          code: "DB_NOT_CONFIGURED",
        });
      }

      try {
        const claims = await getAuthClaims(app, request.auth.sub);

        if (!claims) {
          return sendError(reply, 401, "El usuario autenticado no esta vinculado a un usuario interno de Masterfade", {
            code: "AUTH_SESSION_NOT_FOUND",
          });
        }

        return sendOk(reply, claims);
      } catch (error) {
        request.log.error({ err: error }, "Auth /me error");
        return sendError(reply, 500, "No se pudo obtener la sesion actual", {
          code: "AUTH_ME_ERROR",
          details: error instanceof Error ? error.message : "Unknown auth/me error",
        });
      }
    }
  );

  app.post(
    "/exchange",
    {
      schema: {
        body: exchangeBodySchema,
        response: exchangeResponseSchema,
      },
    },
    async (request, reply) => {
      const supabaseToken = extractSupabaseToken(request);
      if (!supabaseToken) {
        return sendError(reply, 400, "Debes enviar el token de Supabase para realizar el exchange.", {
          code: "AUTH_MISSING_TOKEN",
        });
      }

      if (!app.db) {
        return sendError(reply, 500, "Base de datos no configurada", {
          code: "DB_NOT_CONFIGURED",
        });
      }

      if (!app.supabaseAdmin) {
        return sendError(reply, 500, "Supabase Admin no esta configurado en el backend", {
          code: "SUPABASE_ADMIN_NOT_CONFIGURED",
        });
      }

      const jwtSecret = process.env.JWT_SECRET?.trim();
      if (!jwtSecret) {
        return sendError(reply, 500, "Falta JWT_SECRET en la configuracion del servidor", {
          code: "JWT_SECRET_MISSING",
        });
      }

      try {
        const authResult = await app.supabaseAdmin.auth.getUser(supabaseToken);
        const supabaseUser = authResult.data?.user;
        if (authResult.error || !supabaseUser?.id) {
          return sendError(reply, 401, "Token de Supabase invalido o expirado.", {
            code: "AUTH_SUPABASE_INVALID",
            details: authResult.error?.message || "SUPABASE_GET_USER_FAILED",
          });
        }

        await ensureExchangeInternalUser(app, supabaseUser);

        const claims = await getAuthClaims(app, supabaseUser.id);
        if (!claims) {
          return sendError(reply, 403, "Usuario autenticado sin perfil interno activo en Masterfade", {
            code: "AUTH_USER_NOT_ONBOARDED",
          });
        }

        const accessSync = await syncAccessStateAfterLogin(app, claims.user.id_usuario);
        if (!accessSync.ok) {
          if (accessSync.code === "AUTH_ACCESS_BLOCKED") {
            return sendError(reply, 403, "Tu acceso esta bloqueado o inactivo. Contacta al administrador.", {
              code: "AUTH_ACCESS_BLOCKED",
              details: { estado_acceso: accessSync.estado_acceso },
            });
          }
          return sendError(reply, 403, "Usuario autenticado sin perfil interno activo en Masterfade", {
            code: "AUTH_USER_NOT_ONBOARDED",
          });
        }

        const user = {
          ...claims.user,
          roles: claims.roles,
          branch_ids: claims.branch_ids,
          empresa_id: claims.empresa_id,
          empleado_id: claims.empleado_id,
          cliente_id: claims.cliente_id,
          estado_acceso: accessSync.state?.estado_acceso ?? null,
          credenciales_completadas_at: accessSync.state?.credenciales_completadas_at ?? null,
          ultimo_login_at: accessSync.state?.ultimo_login_at ?? null,
        };

        const token = signAppToken(
          {
            sub: String(claims.user.id_usuario),
            email: user.email ?? extractEmailFromSupabaseUser(supabaseUser) ?? null,
            "mf:roles": claims.roles || [],
            "mf:branch_ids": claims.branch_ids || [],
            token_type: "app",
          },
          jwtSecret
        );

        return sendOk(reply, { token, user });
      } catch (error) {
        if (error?.statusCode && error?.code) {
          return sendError(reply, error.statusCode, error.message, {
            code: error.code,
            details: error.details,
          });
        }

        request.log.error({ err: error }, "Auth exchange error");
        return sendError(reply, 500, "No se pudo completar el exchange de autenticacion", {
          code: "AUTH_EXCHANGE_ERROR",
          details: error instanceof Error ? error.message : "Unknown auth exchange error",
        });
      }
    }
  );

  app.post(
    "/register",
    {
      schema: {
        body: registerBodySchema,
        response: registerResponseSchema,
      },
    },
    async (request, reply) => {
      const body = request.body || {};
      const nombres = normalizeRequiredText(body.nombres);
      const apellidos = normalizeRequiredText(body.apellidos);
      const email = normalizeEmail(body.email);
      const contrasena = String(body.contrasena || "");
      const confirmarContrasena = String(body.confirmar_contrasena || "");
      const consentimientoMarketing = Boolean(body.consentimiento_marketing);
      const aceptaTerminos = body.acepta_terminos === true;
      const requestedBranchId = normalizeOptionalUuid(body.id_sucursal_origen);
      const aceptaTerminosAt = new Date().toISOString();
      const consentimientoMarketingAt = consentimientoMarketing ? aceptaTerminosAt : null;

      if (!nombres || !apellidos) {
        return sendError(reply, 400, "Nombre y apellido son obligatorios.", {
          code: "AUTH_REGISTER_REQUIRED_NAME",
        });
      }
      if (!email || !isValidEmail(email)) {
        return sendError(reply, 400, "Debes ingresar un correo valido.", {
          code: "AUTH_REGISTER_INVALID_EMAIL",
        });
      }
      const passwordValidationError = validatePublicPassword(contrasena);
      if (passwordValidationError) {
        return sendError(reply, 400, passwordValidationError, {
          code: "AUTH_REGISTER_WEAK_PASSWORD",
        });
      }
      if (contrasena !== confirmarContrasena) {
        return sendError(reply, 400, "La confirmacion de contrasena no coincide.", {
          code: "AUTH_REGISTER_PASSWORD_MISMATCH",
        });
      }
      if (!aceptaTerminos) {
        return sendError(reply, 400, "Debes aceptar terminos y condiciones para crear la cuenta.", {
          code: "AUTH_REGISTER_TERMS_REQUIRED",
        });
      }
      if (!app.db) {
        return sendError(reply, 500, "Base de datos no configurada", {
          code: "DB_NOT_CONFIGURED",
        });
      }
      if (!app.supabaseAdmin) {
        return sendError(reply, 500, "Supabase Admin no esta configurado en el backend", {
          code: "SUPABASE_ADMIN_NOT_CONFIGURED",
        });
      }

      const client = await app.db.connect();
      let authUserId = null;
      let transactionStarted = false;

      try {
        const branchId = await resolveRegisterBranchId(client, requestedBranchId);
        await ensureRegisterEmailAvailability(client, email);
        const clienteRoleId = await getClienteRoleId(client);

        const authCreateResult = await app.supabaseAdmin.auth.admin.createUser({
          email,
          password: contrasena,
          email_confirm: true,
          user_metadata: {
            full_name: `${nombres} ${apellidos}`.trim(),
            source: "public_register",
          },
        });

        if (authCreateResult.error || !authCreateResult.data?.user?.id) {
          if (isSupabaseDuplicateError(authCreateResult.error)) {
            return sendError(reply, 409, "El correo ya esta registrado.", {
              code: "AUTH_REGISTER_EMAIL_EXISTS",
            });
          }
          return sendError(reply, 500, "No se pudo crear la identidad de autenticacion.", {
            code: "AUTH_REGISTER_AUTH_CREATE_ERROR",
            details: authCreateResult.error?.message || "AUTH_CREATE_FAILED",
          });
        }

        authUserId = authCreateResult.data.user.id;

        await client.query("BEGIN");
        transactionStarted = true;

        const personaInsert = await client.query(
          `
            INSERT INTO public.personas (nombres, apellidos)
            VALUES ($1, $2)
            RETURNING id_persona
          `,
          [nombres, apellidos]
        );
        const idPersona = personaInsert.rows[0].id_persona;

        await client.query(
          `
            INSERT INTO public.correos (id_persona, direccion_correo, es_principal, verificado)
            VALUES ($1::uuid, $2, TRUE, TRUE)
          `,
          [idPersona, email]
        );

        await client.query(
          `
            INSERT INTO public.usuarios (
              id_usuario,
              id_persona,
              estado,
              estado_acceso,
              credenciales_completadas_at,
              ultimo_login_at
            )
            VALUES ($1::uuid, $2::uuid, TRUE, $3, NOW(), NULL)
          `,
          [authUserId, idPersona, ACCESS_STATUS.ACTIVE]
        );

        await client.query(
          `
            INSERT INTO public.roles_usuarios (
              id_rol,
              id_usuario,
              id_sucursal,
              activo
            )
            VALUES ($1::uuid, $2::uuid, $3::uuid, TRUE)
          `,
          [clienteRoleId, authUserId, branchId]
        );

        const idCliente = await insertClientWithConsents(client, {
          idPersona,
          authUserId,
          branchId,
          consentimientoMarketing,
          aceptaTerminos,
          aceptaTerminosAt,
          consentimientoMarketingAt,
        });

        await client.query("COMMIT");
        transactionStarted = false;

        return sendOk(
          reply,
          {
            user: {
              id_usuario: authUserId,
              id_persona: idPersona,
              id_cliente: idCliente,
              email,
              nombres,
              apellidos,
              estado_acceso: ACCESS_STATUS.ACTIVE,
            },
            cliente: {
              id_cliente: idCliente,
              id_sucursal_origen: branchId,
              estado: true,
            },
            consentimientos: {
              acepta_terminos: true,
              acepta_terminos_at: aceptaTerminosAt,
              consentimiento_marketing: consentimientoMarketing,
              consentimiento_marketing_at: consentimientoMarketingAt,
            },
          },
          { statusCode: 201, requestId: request.id }
        );
      } catch (error) {
        if (transactionStarted) {
          await client.query("ROLLBACK").catch(() => { });
        }
        if (authUserId) {
          // AM: Compensacion segura para no dejar auth.users huerfano si falla el dominio interno.
          const rollback = await app.supabaseAdmin.auth.admin.deleteUser(authUserId);
          if (rollback.error) {
            request.log.error(
              { err: rollback.error, authUserId },
              "Compensacion de auth.users fallo durante registro publico"
            );
          }
        }

        if (error?.statusCode && error?.code) {
          return sendError(reply, error.statusCode, error.message, {
            code: error.code,
            details: error.details,
          });
        }

        if (error?.code === "23505") {
          return sendError(reply, 409, "El correo ya esta registrado.", {
            code: "AUTH_REGISTER_EMAIL_EXISTS",
          });
        }

        request.log.error({ err: error }, "Public register error");
        return sendError(reply, 500, "No se pudo completar el registro de cliente.", {
          code: "AUTH_REGISTER_ERROR",
          details: error instanceof Error ? error.message : "Unknown register error",
        });
      } finally {
        client.release();
      }
    }
  );

  app.post("/forgot-password", async (request, reply) => {
    const email = normalizeEmail(request.body?.email);

    if (!email || !email.includes("@")) {
      return sendError(reply, 400, "Correo invalido", {
        code: "AUTH_INVALID_EMAIL",
      });
    }

    const rateLimitState = registerResetAttempt(email);

    if (rateLimitState.blocked) {
      reply.header("Retry-After", String(rateLimitState.retryAfterSeconds));

      return sendError(reply, 429, "Demasiados intentos para este correo. Intenta mas tarde.", {
        code: "AUTH_RESET_RATE_LIMIT",
        details: {
          retryAfterSeconds: rateLimitState.retryAfterSeconds,
          rateLimit: rateLimitState.rateLimit,
        },
      });
    }

    if (!app.supabaseAdmin) {
      return sendError(reply, 500, "Supabase Admin no esta configurado en el backend", {
        code: "SUPABASE_ADMIN_NOT_CONFIGURED",
      });
    }

    if (!app.mailer?.configured) {
      return sendError(reply, 500, "Servicio SMTP no configurado en backend", {
        code: "MAILER_NOT_CONFIGURED",
      });
    }

    try {
      // AM: Flujo Opcion 2: generar recovery link con Supabase Admin y enviar correo desde backend SMTP.
      const recovery = await generateRecoveryActionLink(app, email);
      if (recovery.found) {
        const delivery = await app.mailer.sendPasswordRecoveryEmail({
          to: email,
          actionLink: recovery.action_link,
          kind: "reset",
        });

        if (!delivery.sent) {
          request.log.error({ email, delivery }, "No se pudo enviar recovery email por SMTP");
        }
      }
    } catch (error) {
      request.log.error({ err: error, email }, "No se pudo procesar forgot-password");
      return sendError(reply, 500, "No se pudo iniciar la recuperacion de contrasena", {
        code: "AUTH_RESET_ERROR",
        details: error instanceof Error ? error.message : "Unknown forgot-password error",
      });
    }

    return sendOk(reply, {
      message: "Si el correo existe, recibiras un enlace para restablecer tu contrasena.",
      rateLimit: rateLimitState.rateLimit,
    });
  });

  app.post(
    "/login",
    {
      schema: {
        body: loginBodySchema,
        response: loginResponseSchema,
      },
    },
    async (request, reply) => {
      const body = request.body || {};
      // AM: Alias de compatibilidad temporal, pero la credencial oficial de Fase 1 es correo.
      const identifier = normalizeEmail(
        body.identifier ?? body.email ?? body.nombre_usuario ?? body.username ?? ""
      );
      const contrasena = String(body.contrasena ?? body.password ?? "").trim();

      if (!identifier || !contrasena) {
        return sendError(reply, 400, "Faltan credenciales: se requiere correo y contrasena", {
          code: "AUTH_MISSING_CREDENTIALS",
        });
      }

      if (!isValidEmail(identifier)) {
        return sendError(reply, 400, "El login de esta etapa requiere un correo valido", {
          code: "AUTH_IDENTIFIER_EMAIL_REQUIRED",
        });
      }

      const jwtSecret = process.env.JWT_SECRET?.trim();
      if (!jwtSecret) {
        return sendError(reply, 500, "Falta JWT_SECRET en la configuracion del servidor", {
          code: "JWT_SECRET_MISSING",
        });
      }

      try {
        if (!app.db) {
          return sendError(reply, 500, "Base de datos no configurada", {
            code: "DB_NOT_CONFIGURED",
          });
        }

        if (!app.supabase) {
          return sendError(reply, 500, "Supabase Auth no esta configurado en el backend", {
            code: "SUPABASE_NOT_CONFIGURED",
            details: "Configura SUPABASE_URL y SUPABASE_ANON_KEY en el entorno del backend.",
          });
        }

        const { data, error } = await app.supabase.auth.signInWithPassword({
          email: identifier,
          password: contrasena,
        });

        if (error || !data?.user?.id) {
          return sendError(reply, 401, error?.message || "Credenciales invalidas", {
            code: "AUTH_INVALID_CREDENTIALS",
          });
        }

        // AM: Validacion de autorizacion interna: no emitimos APP JWT si no existe usuario activo en public.usuarios.
        const claims = await getAuthClaims(app, data.user.id);
        if (!claims) {
          return sendError(reply, 403, "Usuario autenticado sin perfil interno activo en Masterfade", {
            code: "AUTH_USER_NOT_ONBOARDED",
          });
        }

        const accessSync = await syncAccessStateAfterLogin(app, claims.user.id_usuario);
        if (!accessSync.ok) {
          if (accessSync.code === "AUTH_ACCESS_BLOCKED") {
            return sendError(reply, 403, "Tu acceso esta bloqueado o inactivo. Contacta al administrador.", {
              code: "AUTH_ACCESS_BLOCKED",
              details: { estado_acceso: accessSync.estado_acceso },
            });
          }
          return sendError(reply, 403, "Usuario autenticado sin perfil interno activo en Masterfade", {
            code: "AUTH_USER_NOT_ONBOARDED",
          });
        }

        const user = {
          ...claims.user,
          roles: claims.roles,
          branch_ids: claims.branch_ids,
          empresa_id: claims.empresa_id,
          empleado_id: claims.empleado_id,
          cliente_id: claims.cliente_id,
          estado_acceso: accessSync.state?.estado_acceso ?? null,
          credenciales_completadas_at: accessSync.state?.credenciales_completadas_at ?? null,
          ultimo_login_at: accessSync.state?.ultimo_login_at ?? null,
        };

        const token = signAppToken(
          {
            sub: String(claims.user.id_usuario),
            email: user.email ?? data.user.email ?? null,
            "mf:roles": claims.roles || [],
            "mf:branch_ids": claims.branch_ids || [],
            token_type: "app",
          },
          jwtSecret
        );

        return sendOk(reply, { token, user });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Unknown login error";
        request.log.error({ err: error }, "Login error");

        return sendError(reply, 500, "Error al procesar login", {
          code: "AUTH_LOGIN_ERROR",
          details: message,
        });
      }
    }
  );
}
