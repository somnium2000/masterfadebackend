import { sendOk } from "../../utils/response.js";
import { sendError } from "../../utils/errors.js";

// ── JSON Schemas (Fastify usa Ajv internamente) ──

const loginBodySchema = {
  type: "object",
  properties: {
    nombre_usuario: { type: "string", minLength: 1 },
    username: { type: "string", minLength: 1 },
    email: { type: "string", minLength: 1 },
    contrasena: { type: "string", minLength: 1 },
    password: { type: "string", minLength: 1 },
  },
  // Al menos uno de los campos de usuario y uno de password
  anyOf: [
    { required: ["nombre_usuario"] },
    { required: ["username"] },
    { required: ["email"] },
  ],
};

const loginResponseSchema = {
  200: {
    type: "object",
    properties: {
      ok: { type: "boolean" },
      data: {
        type: "object",
        properties: {
          token: { type: "string" },
          user: { type: "object" },
        },
      },
      requestId: { type: "string" },
    },
  },
};

export default async function authRoutes(app) {
  // GET placeholder (compatibilidad)
  app.get("/login", async (request) => {
    return {
      ok: true,
      message: "Login endpoint — usa POST para autenticarte",
      method: "GET",
      requestId: request.id,
    };
  });

  // ── POST /v1/auth/login ──
  app.post(
    "/login",
    {
      schema: {
        body: loginBodySchema,
        response: loginResponseSchema,
      },
    },
    async (request, reply) => {
      const body = request.body || {};

      const nombreUsuario = String(
        body.nombre_usuario ?? body.username ?? body.email ?? ""
      ).trim();

      const contrasena = String(
        body.contrasena ?? body.password ?? ""
      ).trim();

      if (!nombreUsuario || !contrasena) {
        return sendError(reply, 400, "Faltan credenciales: se requiere usuario y contraseña", {
          code: "AUTH_MISSING_CREDENTIALS",
        });
      }

      if (!app.db) {
        return sendError(reply, 500, "Base de datos no configurada", {
          code: "DB_NOT_CONFIGURED",
        });
      }

      const jwtSecret = process.env.JWT_SECRET?.trim();
      if (!jwtSecret) {
        return sendError(reply, 500, "Falta JWT_SECRET en la configuración del servidor", {
          code: "JWT_SECRET_MISSING",
        });
      }

      try {
        const { rows } = await app.db.query(
          "SELECT public.fn_login_usuario($1, $2) AS result",
          [nombreUsuario, contrasena]
        );

        const result = rows?.[0]?.result;

        if (!result || result.ok !== true) {
          return sendError(reply, 401, result?.message || "Credenciales inválidas", {
            code: "AUTH_INVALID_CREDENTIALS",
          });
        }

        const user = result.user;

        const jwtModule = await import("jsonwebtoken");
        const jwt = jwtModule.default;

        const token = jwt.sign(
          {
            sub: String(user.id_usuario),
            nombre_usuario: user.nombre_usuario,
            // Claims con namespace para evitar colisión con Supabase JWT
            "mf:roles": user.roles || [],
            "mf:branch_ids": user.branch_ids || [],
            token_type: "app",
          },
          jwtSecret,
          {
            expiresIn: process.env.JWT_EXPIRES_IN?.trim() || "12h",
            issuer: process.env.APP_JWT_ISSUER || "masterfade-api",
            audience: process.env.APP_JWT_AUDIENCE || "masterfade-app",
          }
        );

        return sendOk(reply, { token, user });
      } catch (error) {
        const msg =
          error instanceof Error ? error.message : "Error desconocido en login";

        request.log.error({ err: error }, "Login error");

        return sendError(reply, 500, "Error al procesar login", {
          code: "AUTH_LOGIN_ERROR",
          details:
            msg.includes("fn_login_usuario")
              ? "La función public.fn_login_usuario no existe. Ejecuta la migración 002_fn_login.sql."
              : undefined,
        });
      }
    }
  );
}
