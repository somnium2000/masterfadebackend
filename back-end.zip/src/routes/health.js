export default async function healthRoutes(app) {
  app.get("/", async (request) => {
    return {
      ok: true,
      requestId: request.id
    };
  });

  app.get("/supabase", async (request, reply) => {
    const supabaseUrl = process.env.SUPABASE_URL?.trim();
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY?.trim();

    if (!supabaseUrl || !supabaseAnonKey) {
      return reply.code(500).send({
        ok: false,
        provider: "supabase",
        status: 500,
        message: "Supabase env vars are not configured",
        requestId: request.id
      });
    }

    const restUrl = new URL("/rest/v1/", supabaseUrl).toString();

    try {
      const response = await fetch(restUrl, {
        method: "GET",
        headers: {
          apikey: supabaseAnonKey,
          authorization: `Bearer ${supabaseAnonKey}`
        }
      });

      const ok = [200, 401, 404].includes(response.status);
      return reply.code(ok ? 200 : 502).send({
        ok,
        provider: "supabase",
        status: response.status,
        requestId: request.id
      });
    } catch (error) {
      return reply.code(502).send({
        ok: false,
        provider: "supabase",
        status: 0,
        message:
          error instanceof Error ? error.message : "Supabase request failed",
        requestId: request.id
      });
    }
  });
}
