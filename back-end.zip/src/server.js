import { buildApp } from "./app.js";
import 'dotenv/config';

const app = await buildApp();
const port = Number(process.env.PORT || 3002);
const host = process.env.HOST || "127.0.0.1";

try {
  await app.listen({ port, host });
} catch (err) {
  app.log.error(err);
  process.exit(1);
}
