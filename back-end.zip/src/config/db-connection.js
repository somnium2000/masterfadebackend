import pg from 'pg';

const { Pool } = pg;

// NUEVO:
// PORQUE: No hardcodear credenciales en código (seguridad + fácil deploy).
// IMPACTO: La conexión depende de variables de entorno.

const pool = new Pool({
  host: process.env.DB_HOST || 'aws-1-us-east-1.pooler.supabase.com',
  port: Number(process.env.DB_PORT || 6543),
  user: process.env.DB_USER,        
  password: process.env.DB_PASSWORD, // ***REDACTED***
  database: process.env.DB_NAME || 'postgres',
  ssl: {
    rejectUnauthorized: false
  }
});

// NUEVO:
// PORQUE: Probar conexión en arranque ayuda a detectar fallos rápido.
// IMPACTO: Solo se ejecuta si DB_TEST_CONNECTION=true para no ensuciar logs en prod.
if (process.env.DB_TEST_CONNECTION === 'true') {
  pool.connect((err, client, release) => {
    if (err) {
      console.error('Error al conectar con la base de datos:', err.stack);
    } else {
      console.log('¡Conexión exitosa a Supabase!');
      release();
    }
  });
}

export default pool;