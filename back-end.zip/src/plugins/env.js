import dotenv from "dotenv";

export default async function envPlugin() {
  dotenv.config();
}
